import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, RefreshCw, AlertTriangle } from 'lucide-react';
import * as tf from '@tensorflow/tfjs-core';
import '@tensorflow/tfjs-backend-webgl';
import * as poseDetection from '@tensorflow-models/pose-detection';

interface Point {
  x: number;
  y: number;
}

interface Angles {
  neckFlexion: number;
  trunkLean: number;
}

export default function Screen3Results({
  imageSrc,
  onBack,
}: {
  imageSrc: string;
  onBack: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [angles, setAngles] = useState<Angles | null>(null);
  const [rosaScore, setRosaScore] = useState<number | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const runAnalysis = async () => {
      try {
        setIsAnalyzing(true);
        setErrorMsg(null);

        // 1. Load the image properly via Promise
        const img = new Image();
        img.src = imageSrc;
        img.crossOrigin = "anonymous";
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = () => reject(new Error("Failed to load image"));
        });

        if (!isMounted) return;

        // 1. Wait for TF to be ready
        await tf.ready();

        // 2. Explicitly force WebGL (bypass the WebGPU crash)
        await tf.setBackend('webgl');

        // 3. NOW create the detector
        const model = poseDetection.SupportedModels.BlazePose;
        const detectorConfig = {
          runtime: 'tfjs',
          enableSmoothing: true,
          modelType: 'full'
        };
        const detector = await poseDetection.createDetector(model, detectorConfig as any);

        // 4. Estimate poses
        const poses = await detector.estimatePoses(img);
        
        if (!isMounted) return;

        if (poses.length > 0) {
          const pose = poses[0];
          const keypoints = pose.keypoints;

          // Find best side (left or right) based on confidence
          const leftEar = keypoints.find((k) => k.name === 'left_ear');
          const rightEar = keypoints.find((k) => k.name === 'right_ear');
          const leftShoulder = keypoints.find((k) => k.name === 'left_shoulder');
          const rightShoulder = keypoints.find((k) => k.name === 'right_shoulder');
          const leftHip = keypoints.find((k) => k.name === 'left_hip');
          const rightHip = keypoints.find((k) => k.name === 'right_hip');

          const leftConfidence = (leftEar?.score || 0) + (leftShoulder?.score || 0) + (leftHip?.score || 0);
          const rightConfidence = (rightEar?.score || 0) + (rightShoulder?.score || 0) + (rightHip?.score || 0);

          const isLeft = leftConfidence > rightConfidence;
          
          const ear = isLeft ? leftEar : rightEar;
          const shoulder = isLeft ? leftShoulder : rightShoulder;
          const hip = isLeft ? leftHip : rightHip;

          if (ear && shoulder && hip) {
            // Calculate angles
            const calculateAngle = (p1: Point, p2: Point) => {
              const dx = p1.x - p2.x;
              const dy = p2.y - p1.y; // Y is inverted to fix canvas axis
              let angle = Math.atan2(dx, dy) * (180 / Math.PI);
              return angle;
            };

            const neckFlexion = calculateAngle(ear, shoulder);
            const trunkLean = calculateAngle(shoulder, hip);

            setAngles({ neckFlexion, trunkLean });

            // Calculate ROSA Score
            let score = 1; // Base score
            if (trunkLean > 15 || trunkLean < -15) score += 2;
            if (neckFlexion > 20) score += 2;
            setRosaScore(score);

            // Draw on canvas
            const canvas = canvasRef.current;
            if (canvas) {
              const ctx = canvas.getContext('2d');
              if (ctx) {
                // Set canvas dimensions to match image natural size
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;

                // Draw image
                ctx.drawImage(img, 0, 0);

                // Draw skeleton
                ctx.strokeStyle = '#10b981'; // emerald-500
                ctx.lineWidth = 4;
                ctx.fillStyle = '#10b981';

                const drawPoint = (p: Point) => {
                  ctx.beginPath();
                  ctx.arc(p.x, p.y, 6, 0, 2 * Math.PI);
                  ctx.fill();
                };

                const drawLine = (p1: Point, p2: Point) => {
                  ctx.beginPath();
                  ctx.moveTo(p1.x, p1.y);
                  ctx.lineTo(p2.x, p2.y);
                  ctx.stroke();
                };

                // Draw points and lines
                drawPoint(ear);
                drawPoint(shoulder);
                drawPoint(hip);
                drawLine(ear, shoulder);
                drawLine(shoulder, hip);

                // Draw text labels
                ctx.font = '24px Arial';
                ctx.fillStyle = '#ffffff';
                ctx.shadowColor = '#000000';
                ctx.shadowBlur = 4;
                ctx.fillText(`Neck: ${Math.round(neckFlexion)}°`, ear.x + 15, ear.y);
                ctx.fillText(`Trunk: ${Math.round(trunkLean)}°`, shoulder.x + 15, shoulder.y);
              }
            }
          } else {
            setErrorMsg("Could not detect necessary body parts (ear, shoulder, hip).");
          }
        } else {
          setErrorMsg("No person detected in the image.");
        }
      } catch (error: any) {
        console.error('Error analyzing pose:', error);
        setErrorMsg(error.message || "An error occurred during analysis.");
      } finally {
        if (isMounted) {
          setIsAnalyzing(false);
        }
      }
    };

    runAnalysis();

    return () => {
      isMounted = false;
    };
  }, [imageSrc]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="flex items-center p-4 bg-white border-b border-slate-200 sticky top-0 z-10">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-600 hover:text-slate-900">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-semibold ml-2 text-slate-900">Results & Analysis</h1>
      </header>

      <main className="flex-1 flex flex-col">
        {/* Top Half: Canvas */}
        <div className="relative w-full bg-slate-900 aspect-[3/4] sm:aspect-video md:aspect-auto md:h-[50vh] flex items-center justify-center overflow-hidden">
          {isAnalyzing && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-900/80 text-white space-y-4 backdrop-blur-sm">
              <RefreshCw className="w-8 h-8 animate-spin text-blue-500" />
              <p className="font-medium">Analyzing Posture...</p>
            </div>
          )}
          
          {errorMsg && !isAnalyzing && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-900 text-white space-y-4 p-6 text-center">
              <AlertTriangle className="w-12 h-12 text-red-500" />
              <p className="font-medium text-red-400">{errorMsg}</p>
              <p className="text-sm text-slate-400">Please try again with a clearer side-view photo.</p>
            </div>
          )}

          <canvas
            ref={canvasRef}
            className={`max-w-full max-h-full object-contain ${isAnalyzing || errorMsg ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}
          />
        </div>

        {/* Bottom Half: Results Data */}
        <div className="flex-1 bg-slate-50 p-4 sm:p-6 overflow-y-auto">
          {!isAnalyzing && !errorMsg && angles && rosaScore !== null ? (
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Score Card */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Final ROSA Score
                </h2>
                <div className="flex items-baseline space-x-3">
                  <span className="text-5xl font-bold text-slate-900">{rosaScore}</span>
                  <span className={`text-lg font-medium ${rosaScore <= 2 ? 'text-emerald-600' : rosaScore <= 4 ? 'text-amber-600' : 'text-red-600'}`}>
                    - {rosaScore <= 2 ? 'IDEAL' : rosaScore <= 4 ? 'WARNING' : 'HIGH RISK'}
                  </span>
                </div>
              </div>

              {/* Angle Payload */}
              <div className="bg-slate-900 rounded-2xl p-6 shadow-sm text-slate-300 font-mono text-sm overflow-x-auto">
                <div className="text-slate-500 mb-2">{`// Raw Angle Payload`}</div>
                <pre>
{JSON.stringify({
  timestamp: new Date().toISOString(),
  angles: {
    neck_flexion_deg: Number(angles.neckFlexion.toFixed(2)),
    trunk_lean_deg: Number(angles.trunkLean.toFixed(2))
  },
  iso_9241_compliance: {
    neck_ok: angles.neckFlexion <= 20,
    trunk_ok: angles.trunkLean >= -15 && angles.trunkLean <= 15
  }
}, null, 2)}
                </pre>
              </div>

              {/* ISO 9241 Checks */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
                <h3 className="font-semibold text-slate-900">ISO 9241 Compliance Checks</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <div>
                      <div className="font-medium text-slate-900">Neck Flexion</div>
                      <div className="text-sm text-slate-500">Should be ≤ 20°</div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${angles.neckFlexion <= 20 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                      {Math.round(angles.neckFlexion)}°
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <div>
                      <div className="font-medium text-slate-900">Trunk Lean</div>
                      <div className="text-sm text-slate-500">Should be between -15° and 15°</div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${angles.trunkLean >= -15 && angles.trunkLean <= 15 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                      {Math.round(angles.trunkLean)}°
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : !isAnalyzing && (
            <div className="text-center text-slate-500 py-12">
              Could not detect posture. Please try again with a clearer side-view photo.
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
