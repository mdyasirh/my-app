import { useState, useRef, useCallback } from 'react';
import Webcam from 'react-webcam';
import { ArrowLeft, Image as ImageIcon } from 'lucide-react';

export default function Screen2Capture({
  onBack,
  onCapture,
}: {
  onBack: () => void;
  onCapture: (imageSrc: string) => void;
}) {
  const webcamRef = useRef<Webcam>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isReady, setIsReady] = useState(true); // Mock validation state

  const handleCapture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onCapture(imageSrc);
    }
  }, [webcamRef, onCapture]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onCapture(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex flex-col relative">
      <header className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between p-4 bg-gradient-to-b from-black/50 to-transparent">
        <button onClick={onBack} className="p-2 -ml-2 text-white/80 hover:text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex-1 flex justify-center">
          {isReady ? (
            <div className="bg-emerald-500/20 text-emerald-400 px-4 py-1.5 rounded-full text-sm font-medium border border-emerald-500/30 backdrop-blur-md">
              ✅ Ready
            </div>
          ) : (
            <div className="bg-red-500/20 text-red-400 px-4 py-1.5 rounded-full text-sm font-medium border border-red-500/30 backdrop-blur-md">
              ⚠️ Adjust your position
            </div>
          )}
        </div>
        <div className="w-10" /> {/* Spacer for centering */}
      </header>

      <main className="flex-1 relative flex items-center justify-center overflow-hidden">
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          videoConstraints={{ facingMode: 'environment' }}
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        {/* Framing Bracket Overlay */}
        <div className={`absolute inset-8 border-2 rounded-3xl pointer-events-none transition-colors duration-300 ${isReady ? 'border-emerald-500/50' : 'border-red-500/50'}`}>
          {/* Corner brackets */}
          <div className={`absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 rounded-tl-3xl ${isReady ? 'border-emerald-500' : 'border-red-500'}`} />
          <div className={`absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 rounded-tr-3xl ${isReady ? 'border-emerald-500' : 'border-red-500'}`} />
          <div className={`absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 rounded-bl-3xl ${isReady ? 'border-emerald-500' : 'border-red-500'}`} />
          <div className={`absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 rounded-br-3xl ${isReady ? 'border-emerald-500' : 'border-red-500'}`} />
        </div>
      </main>

      <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 via-black/50 to-transparent flex items-center justify-between">
        <div className="w-12" /> {/* Spacer */}
        
        <button
          onClick={handleCapture}
          className="w-20 h-20 rounded-full border-4 border-white/80 flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <div className="w-16 h-16 bg-white rounded-full" />
        </button>

        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors backdrop-blur-md"
        >
          <ImageIcon className="w-6 h-6 text-white" />
        </button>
        <input
          type="file"
          accept="image/jpeg, image/png, image/heic"
          ref={fileInputRef}
          onChange={handleFileUpload}
          className="hidden"
        />
      </div>
    </div>
  );
}
