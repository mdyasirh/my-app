'use client';

import { useState } from 'react';
import Screen1Guide from '@/components/Screen1Guide';
import Screen2Capture from '@/components/Screen2Capture';
import Screen3Results from '@/components/Screen3Results';

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<1 | 2 | 3>(1);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  const handleNextToCapture = () => {
    setCurrentScreen(2);
  };

  const handleBackToGuide = () => {
    setCurrentScreen(1);
  };

  const handleCapture = (imageSrc: string) => {
    setCapturedImage(imageSrc);
    setCurrentScreen(3);
  };

  const handleBackToCapture = () => {
    setCapturedImage(null);
    setCurrentScreen(2);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      {currentScreen === 1 && <Screen1Guide onNext={handleNextToCapture} />}
      {currentScreen === 2 && (
        <Screen2Capture onBack={handleBackToGuide} onCapture={handleCapture} />
      )}
      {currentScreen === 3 && capturedImage && (
        <Screen3Results imageSrc={capturedImage} onBack={handleBackToCapture} />
      )}
    </div>
  );
}
